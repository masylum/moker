import { appendFileSync, writeFileSync } from 'node:fs'
import { simulateParallel } from './scripts/lib/simulation-pool'
const count = Number(process.argv[2] ?? 128)
const started = Date.now()
writeFileSync('results.jsonl','')
await simulateParallel({count,workers:10,game: i => ({seed:`twin-placement-v1-${i%64}`,mode:'riichi',orbits:i<64?4:1,tournamentGames:i<64?1:4,heuristicSamples:24,collectDecisions:i%64<5,collectGameSummaries:true}),onResult:(r,i)=>{
appendFileSync('results.jsonl',JSON.stringify({index:i,seed:r.seed,format:i<64?'continuous':'reset',twinPaths:(r as any).twinPaths,hands:r.state.handResults,games:r.gameSummaries})+'\n')
if(i%64<5)writeFileSync(`sample-${i}.json`,JSON.stringify(r))
if((i+1)%16===0)console.log(`${i+1}/${count} ${((Date.now()-started)/1000).toFixed(1)}s`)
}})
writeFileSync('timing.json',JSON.stringify({seconds:(Date.now()-started)/1000,count,samples:24,workers:10}))
