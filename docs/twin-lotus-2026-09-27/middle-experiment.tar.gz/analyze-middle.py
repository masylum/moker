from pathlib import Path
import json,tarfile,collections,random,statistics
r=Path(__file__).parent;w=r
with tarfile.open(r/'experiment.tar.gz') as t:
 arms={a:[json.loads(l) for l in t.extractfile(f'{folder}/results.jsonl').read().splitlines()] for a,folder in [('automatic','control'),('below-dragons','ranked')]}
arms['above-dragons']=[json.loads(l) for l in (w/'ranked/results.jsonl').read_text().splitlines()]
summary={}
for arm,runs in arms.items():
 for fmt in ['continuous','reset']:
  totals=collections.Counter();rows=collections.defaultdict(collections.Counter);cases=[]
  for run in runs:
   if run['format']!=fmt:continue
   totals['runs']+=1
   paths={(x['game'],x['hand'],x['player']):dict(x) for x in run.get('twinPaths',[])}
   if arm=='above-dragons':
    # Include terminal acquisitions: the engine may settle within one step.
    for h in run['hands']:
     for p in h['players']:
      key=(h['orbitValue']/5,h['handNumber'],p['playerId']);flowers=sum(c['kind']=='flower' for c in p['cards']);rank=p['score']['total']
      if flowers==2 or key in paths:
       path=paths.setdefault(key,dict(sawTwin=False,sawTwinAsBest=False,strongerAfterTwin=False,brokeTwinForStronger=False))
       if path['sawTwinAsBest'] and flowers!=1 and rank>9.5:
        path['strongerAfterTwin']=True
        if flowers==0:path['brokeTwinForStronger']=True
       if flowers==2:
        path['sawTwin']=True
        if rank==9.5:path['sawTwinAsBest']=True
    for path in paths.values():
     for k in ['sawTwin','sawTwinAsBest','strongerAfterTwin','brokeTwinForStronger']:totals[k]+=path[k]
   for h in run['hands']:
    totals['hands']+=1;totals['allInHands']+=bool(h['allInPlayerIds']);totals['showdownHands']+=h['reason']=='showdown';totals['street4']+=any(b['street']==4 for b in h['bettingHistory'])
    for p in h['players']:
     if not p['openingCards']:continue
     totals['holdings']+=1;flowers=sum(c['kind']=='flower' for c in p['cards']);twins=flowers==2
     kind='twin-lotus' if twins and arm=='automatic' else (p['score']['combinations'][0]['kind'] if p['score']['combinations'] else 'high-card')
     if flowers!=1:rows[kind]['retained']+=1
     show=h['reason']=='showdown' and not p['folded'] and not p['eliminated'];win=p['playerId'] in h['winnerIds'];credit=1/len(h['winnerIds']) if win else 0
     if show and flowers!=1:rows[kind]['show']+=1;rows[kind]['winCredit']+=credit
     if twins:
      totals['retainedTwins']+=1;totals['twinUncontested']+=win and h['reason']=='uncontested';totals['twinFolds']+=p['folded'];totals['twinRiichi']+=p['riichi'];totals['twinNet']+=p['netChips'] or 0;totals['builtTwins']+=sum(c['kind']=='flower' for c in p['openingCards'])!=2
      totals['strongerOrdinaryWithTwins']+=kind!='twin-lotus';totals['twinBothPublic']+=sum(c['kind']=='flower' for c in p['publicCards'])==2
      if show or p['folded']:cases.append({'seed':run['seed'],'game':h['orbitValue']/5,'hand':h['handNumber'],'player':p['playerId'],'kind':kind,'show':show,'win':win,'fold':p['folded'],'net':p['netChips'],'rivals':[q['score']['combinations'][0]['kind'] if q['score']['combinations'] else 'high-card' for q in h['players'] if q['playerId']!=p['playerId'] and not q['folded'] and not q['eliminated']]})
  summary[f'{arm}-{fmt}']={'totals':dict(totals),'rows':{k:dict(v) for k,v in rows.items()},'cases':cases}
(r/'middle-analysis.json').write_text(json.dumps(summary,indent=2));print(json.dumps({k:{'totals':v['totals'],'twin':v['rows'].get('twin-lotus')} for k,v in summary.items()},indent=2))
