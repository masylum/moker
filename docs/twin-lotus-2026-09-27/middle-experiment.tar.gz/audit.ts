import {readFileSync,writeFileSync} from 'node:fs'
import assert from 'node:assert/strict'
import {scoreHand,compareHandScores} from './control/src/game/scoring'
let showdowns=0,holdings=0
for(const line of readFileSync(new URL('./ranked/results.jsonl',import.meta.url),'utf8').trim().split('\n')){
 const run=JSON.parse(line)
 for(const h of run.hands){
  if(h.reason!=='showdown')continue
  const contenders=h.players.filter((p:any)=>!p.folded&&!p.eliminated)
  let eligible=contenders.filter((p:any)=>p.cards.filter((c:any)=>c.kind==='flower').length!==1)
  if(!eligible.length){assert.deepEqual([...h.winnerIds].sort(),contenders.map((p:any)=>p.playerId).sort());showdowns++;continue}
  const scores=eligible.map((p:any)=>{
   const s=scoreHand(p.cards)
   if(p.cards.filter((c:any)=>c.kind==='flower').length===2&&s.total<9.5){s.total=9.5;s.tieBreak=[]}
   assert.equal(p.score.total,s.total)
   holdings++
   return {id:p.playerId,score:s}
  })
  scores.sort((a:any,b:any)=>compareHandScores(b.score,a.score))
  const expected=scores.filter((p:any)=>compareHandScores(p.score,scores[0].score)===0).map((p:any)=>p.id).sort()
  assert.deepEqual([...h.winnerIds].sort(),expected)
  showdowns++
 }
}
writeFileSync(new URL('./middle-settlement-audit.json',import.meta.url),JSON.stringify({showdowns,holdings,passed:true},null,2))
console.log({showdowns,holdings,passed:true})
