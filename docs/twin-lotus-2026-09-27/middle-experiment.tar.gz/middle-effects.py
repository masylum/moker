import json,random,statistics
from pathlib import Path
root=Path(__file__).parent
import tarfile
with tarfile.open(root/'experiment.tar.gz') as t:
 arms={'control':{r['index']:r for r in map(json.loads,t.extractfile('ranked/results.jsonl').read().splitlines())},'ranked':{r['index']:r for r in map(json.loads,(root/'ranked/results.jsonl').read_text().splitlines())}}

def measures(r):
 hs=r['hands'];ts=[(h,p) for h in hs for p in h['players'] if sum(c['kind']=='flower' for c in p['cards'])==2]
 return {'allInRate':sum(bool(h['allInPlayerIds']) for h in hs)/len(hs),'showdownRate':sum(h['reason']=='showdown' for h in hs)/len(hs),'street4Rate':sum(any(b['street']==4 for b in h['bettingHistory']) for h in hs)/len(hs),'retainedTwinsPerRun':len(ts),'twinNetPerRun':sum(p['netChips'] or 0 for h,p in ts),'loansPerRun':sum(p['loans'] for g in r['games'] for p in g['players'])}
rng=random.Random(2781);out={}
for fmt,indices in [('continuous',range(64)),('reset',range(64,128))]:
 differences=[{k:v-measures(arms['control'][i])[k] for k,v in measures(arms['ranked'][i]).items()} for i in indices]
 out[fmt]={}
 for k in differences[0]:
  ds=[d[k] for d in differences];boots=sorted(statistics.mean(rng.choices(ds,k=len(ds))) for _ in range(5000))
  out[fmt][k]={'rankedMinusControl':statistics.mean(ds),'pairedBootstrap95':[boots[125],boots[4874]]}
(root/'middle-paired-effects.json').write_text(json.dumps(out,indent=2));print(json.dumps(out,indent=2))
