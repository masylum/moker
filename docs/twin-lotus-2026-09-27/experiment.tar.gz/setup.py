from pathlib import Path
import shutil, hashlib, json
root=Path.cwd(); out=root/'docs/twin-lotus-2026-09-27'
for arm in ['control','ranked']:
 p=out/arm
 (p/'src').mkdir(parents=True,exist_ok=True)
 shutil.copytree(root/'src/game',p/'src/game',dirs_exist_ok=True)
 shutil.copytree(root/'scripts/lib',p/'scripts/lib',dirs_exist_ok=True)
 shutil.copy(root/'package.json',p/'package.json')
 if not (p/'node_modules').exists(): (p/'node_modules').symlink_to(root/'node_modules')
(out/'source-hashes.json').write_text(json.dumps({str(p.relative_to(root)):hashlib.sha256(p.read_bytes()).hexdigest() for p in (root/'src/game').glob('*.ts')},indent=2))
p=out/'ranked/src/game'
def patch(file,a,b):
 f=p/file;s=f.read_text();assert a in s,(file,a);f.write_text(s.replace(a,b))
patch('types.ts','export type CombinationKind =','export type CombinationKind =\n  | "twin-lotus"')
patch('hand-ranks.ts','  "pung-eye": 8,','  "pung-eye": 8,\n  "twin-lotus": 8.5,')
patch('scoring.ts','export function scoreHand(cards:', '''export function scoreHand(cards: readonly Card[], mode: "basic" | "riichi" = "riichi"): HandScore {
  const ordinary = scoreOrdinaryHand(cards, mode)
  const flowers = cards.filter(c => c.kind === "flower")
  if (mode !== "riichi" || flowers.length !== 2 || ordinary.total > 8.5) return ordinary
  return { total: 8.5, selectedCardIds: flowers.map(c => c.id), tieBreak: [], combinations: [{kind: "twin-lotus", score: 8.5, cardIds: flowers.map(c => c.id), label: "Twin Lotus", description: "Twin Lotus between Pung + Eyes and Three Dragons"}] }
}

function scoreOrdinaryHand(cards:''')
f=p/'engine.ts';s=f.read_text();start=s.index('    const twins = contenders.filter(');end=s.index('    const eligible =',start);s=s[:start]+s[end:];f.write_text(s)
f=p/'heuristic.ts';s=f.read_text();start=s.index('  const certain = hasTwinLotus');end=s.index('  const sampledEquity',start);s=s[:start]+'  const certain = false\n'+s[end:];s=s.replace('    if (hasTwinLotus([...own.privateCards, ...own.publicCards])) return 1\n','').replace('hasTwinLotus(cards) ? 14 : scoreHandStrength(cards, state.config.mode).total','scoreHandStrength(cards, state.config.mode).total').replace('    !hasTwinLotus(ownCards) &&\n','').replace('      if (hasTwinLotus(visible)) return true\n','').replace('lotusCount === 2 ? { total: 14, tieBreak: [] } : scoreHandStrength(cards, mode)','scoreHandStrength(cards, mode)').replace('hasTwinLotus(cards) ? 14 : scored.total','scored.total');f.write_text(s)
f=p/'hand-progress.ts';s=f.read_text().replace('const definitions: HandDefinition[] = [','const definitions: HandDefinition[] = [\n  exactDefinition("twin-lotus", "Twin Lotus", 2, [createDeck().filter(c => c.kind === "flower").map(c => requirement(c, true))]),').replace('["pung-eye", "three-dragons-eye", "kong", "long-chow"]','["pung-eye", "three-dragons-eye", "kong", "long-chow", "twin-lotus"]');f.write_text(s)
