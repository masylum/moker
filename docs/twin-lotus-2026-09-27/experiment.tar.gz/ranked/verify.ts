import assert from 'node:assert/strict'
import {createDeck} from './src/game/cards'
import {scoreHand} from './src/game/scoring'
import {GameEngine} from './src/game/engine'
import {analyzePokerMath} from './src/game/heuristic'
const deck=createDeck(), flowers=deck.filter(c=>c.kind==='flower')
const dragons=deck.filter(c=>c.kind==='dragon'&&c.id.endsWith('-1'))
const pung=deck.filter(c=>c.kind==='numbered'&&c.rank===1&&c.suit==='bamboo')
const eye=deck.filter(c=>c.kind==='wind').slice(0,2)
assert.equal(pung.length,3)
assert.equal(scoreHand([...pung,...eye]).total,8)
assert.equal(scoreHand(flowers).total,8.5)
assert.equal(scoreHand(dragons).total,9)
assert.equal(scoreHand([...flowers,...dragons,...eye]).total,11)
assert.equal(scoreHand([...flowers.slice(0,1),...pung]).total,6)
const engine=GameEngine.create([{id:'a',name:'a',controller:'heuristic'},{id:'b',name:'b',controller:'heuristic'}],{mode:'riichi',seed:'verify',heuristicSamples:24})
for(const p of engine.state.players){p.folded=false;p.eliminated=false;p.privateCards=[];p.publicCards=[]}
const [a,b]=engine.state.players
function set(x:any,cards:any[]){x.privateCards=[];x.publicCards=cards;x.score=scoreHand(cards)}
set(a,flowers);set(b,dragons)
assert.deepEqual((engine as any).showdownWinners([a,b]).map((p:any)=>p.id),['b'])
const equity=analyzePokerMath(engine.state,'a',24)
assert.ok(equity.showdownEquity<1)
set(b,[...pung,...eye]);assert.deepEqual((engine as any).showdownWinners([a,b]).map((p:any)=>p.id),['a'])
set(a,[...flowers,...dragons,...eye]);set(b,dragons)
assert.deepEqual((engine as any).showdownWinners([a,b]).map((p:any)=>p.id),['a'])
console.log(JSON.stringify({checks:10,twinEquityAgainstDragons:equity.showdownEquity,passed:true}))
import {scoreHand as controlScore} from '../control/src/game/scoring'
import {SeededRandom} from './src/game/random'
const random = new SeededRandom('twin-regression')
for(let i=0;i<1000;i++){
 const cards=random.shuffle(deck).slice(0,7)
 if(cards.filter(c=>c.kind==='flower').length!==2)assert.deepEqual(scoreHand(cards),controlScore(cards))
 assert.deepEqual(scoreHand(cards,'basic'),controlScore(cards,'basic'))
}
assert.notEqual(scoreHand([flowers[0]!,...deck.filter(c=>c.kind==='joker')]).total,8.5)
console.log('1000 randomized unchanged-hand comparisons and Joker exclusion passed')
