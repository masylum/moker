import json,math
from pathlib import Path
from collections import Counter
root=Path(__file__).parent;a=json.loads((root/'analysis.json').read_text())
pooled={}
for arm in ['control','ranked']:
 t=Counter();rows={}
 for fmt in ['continuous','reset']:
  t.update(a[f'{arm}-{fmt}']['totals'])
  for k,r in a[f'{arm}-{fmt}']['rows'].items():rows.setdefault(k,Counter()).update(r)
 pooled[arm]={'totals':t,'rows':rows}
pct=lambda x,n:f'{100*x/n:.1f}%' if n else '—'
lines=['# Results: Twin Lotus at the proposed rank','', '256 simulations, 640 constituent games, 4,096 table hands. Each arm: 128 simulations / 2,048 hands, half continuous stacks and half four-game stack resets. **24 samples per decision; 10 workers.** Long Chow is included. These are actual played games, not random-hand frequency samples.','', '| Twin Lotus measure | Automatic-win control | Ranked below Three Dragons |','|---|---:|---:|']
for label,key in [('Opening holdings','openingTwins'),('Retained holdings (including folds)','retainedTwins'),('Built after opening','builtTwins'),('Folded while retaining Twins','foldedTwins'),('Uncontested wins','twinUncontested'),('Showdown appearances, including stronger ordinary combinations','twinShow'),('Showdown win credit, including stronger ordinary combinations','twinShowWins'),('Both Lotuses public at end of hand','twinBothPublic')]:
 lines.append(f'| {label} | {pooled["control"]["totals"][key]:g} | {pooled["ranked"]["totals"][key]:g} |')
lines+=['','## Showdown performance by format','','These rows count **Twin Lotus itself as the scoring category**. A holding with both Lotuses and a stronger ordinary combination is reported under that ordinary combination instead. Split pots use fractional win credit.','','| Format | Control Twin wins / showdowns | Ranked Twin wins / showdowns | Ranked uncontested Twin-holding wins |','|---|---:|---:|---:|']
for fmt in ['continuous','reset']:
 c=a['control-'+fmt]['rows']['twin-lotus'];r=a['ranked-'+fmt]['rows']['twin-lotus'];t=a['ranked-'+fmt]['totals']
 lines.append(f'| {fmt} | {c["winCredit"]:g}/{c["show"]} ({pct(c["winCredit"],c["show"])}) | {r["winCredit"]:g}/{r["show"]} ({pct(r["winCredit"],r["show"])}) | {t["twinUncontested"]} |')
lines+=['','## Whole Advanced ladder under the ranked rule','','Retained frequency uses all 8,192 dealt player-hands as the denominator, counting the strongest category at hand end, including folds but excluding single-Lotus disqualified holdings. It is not opening rarity and reflects strategic choices. Showdown entrants exclude folds and disqualified players.','','| Category, low to high | Eligible retained | Frequency | Showdown win credit / appearances | Win rate |','|---|---:|---:|---:|---:|']
order=['high-card','eye','chow','two-eyes','chow-eye','pung','three-winds','pung-eye','twin-lotus','three-dragons','long-chow','three-dragons-eye','four-winds','kong']
for k in order:
 r=pooled['ranked']['rows'].get(k,Counter());n=r.get('show',0);w=r.get('winCredit',0);ret=r.get('eligibleRetained',0)
 lines.append(f'| {k} | {ret} | {pct(ret,8192)} | {w:g}/{n} | {pct(w,n)} |')
lines+=['','## Table-level effects','','| Measure | Control continuous | Ranked continuous | Control reset | Ranked reset |','|---|---:|---:|---:|---:|']
for label,key in [('All-in hands','allInHands'),('Showdown hands','showdowns'),('Hands with street-four betting','street4')]:
 vals=[pct(a[f'{arm}-{fmt}']['totals'][key],1024) for fmt in ['continuous','reset'] for arm in ['control','ranked']]
 lines.append('| '+label+' | '+' | '.join(vals)+' |')
for label,key in [('Loans across constituent games','loans'),('Total net chips in Twin-holding hands','twinNetChips')]:
 vals=[str(a[f'{arm}-{fmt}']['totals'][key]) for fmt in ['continuous','reset'] for arm in ['control','ranked']]
 lines.append('| '+label+' | '+' | '.join(vals)+' |')
lines+=['','Chip totals pool differently sized pots and exclude opportunity costs from unsuccessful singleton attempts. They are not a causal estimate of how much a Lotus card is worth. Paired per-tournament bootstrap intervals are saved in `paired-effects.json`; use those before treating small whole-table differences as established. Continuous and reset formats reuse seed labels, so pooled counts are descriptive, not independent replications.','']
(root/'results.md').write_text('\n'.join(lines))
(root/'pooled.json').write_text(json.dumps(pooled,indent=2))
print('\n'.join(lines))
