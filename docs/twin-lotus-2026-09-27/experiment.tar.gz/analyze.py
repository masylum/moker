import json, math
from pathlib import Path
from collections import Counter,defaultdict
root=Path(__file__).parent
summary={};examples=[]
def twin(cards):return sum(c['kind']=='flower' for c in cards)==2
def row():return Counter()
for arm in ['control','ranked']:
 data=[json.loads(s) for s in (root/arm/'results.jsonl').read_text().splitlines()]
 for fmt in ['continuous','reset']:
  totals=Counter(); rows=defaultdict(row); cases=[]
  for run in data:
   if run['format']!=fmt:continue
   totals['runs']+=1
   for h in run['hands']:
    totals['hands']+=1;totals['showdowns']+=h['reason']=='showdown';totals['allInHands']+=bool(h['allInPlayerIds']);totals['street4']+=any(b['street']==4 for b in h['bettingHistory'])
    for p in h['players']:
     if not p['openingCards']:continue
     totals['holdings']+=1
     istwin=twin(p['cards']); opening=twin(p['openingCards']); score=p['score']; kind='twin-lotus' if istwin and (arm=='control' or score['total']==8.5) else (score['combinations'][0]['kind'] if score['combinations'] else 'high-card')
     rows[kind]['retained']+=1
     rows[kind]['eligibleRetained']+=sum(c['kind']=='flower' for c in p['cards'])!=1
     rows[kind]['folded']+=p['folded']
     if sum(c['kind']=='flower' for c in p['cards'])==0:rows[kind]['noLotusRetained']+=1
     if opening:totals['openingTwins']+=1
     show=h['reason']=='showdown' and not p['folded'] and not p['eliminated']
     won=p['playerId'] in h['winnerIds'];credit=1/len(h['winnerIds']) if won else 0
     if show and not p['lotusDisqualified']:
      rows[kind]['show']+=1;rows[kind]['winCredit']+=credit
     if istwin:
      totals['twinBothPublic']+=sum(c['kind']=='flower' for c in p['publicCards'])==2
      totals['twinShowBothPublic']+=show and sum(c['kind']=='flower' for c in p['publicCards'])==2
      totals['retainedTwins']+=1;totals['builtTwins']+=not opening;totals['foldedTwins']+=p['folded'];totals['twinShow']+=show;totals['twinShowWins']+=credit if show else 0;totals['twinUncontested']+=h['reason']=='uncontested' and won;totals['twinNetChips']+=p['netChips'] or 0
      if score['total']>8.5:totals['twinWithStrongerOrdinary']+=1
      rivals=[q for q in h['players'] if q['playerId']!=p['playerId'] and not q['folded'] and not q['eliminated'] and not q['lotusDisqualified']]
      defeated=[q['score']['combinations'][0]['kind'] if q['score']['combinations'] else 'high-card' for q in rivals if q['score']['total']>max(8.5,score['total'])]
      if show and defeated:totals['twinsFacingBetterAtProposedRank']+=1
      case={'arm':arm,'format':fmt,'seed':run['seed'],'game':h['orbitValue']/5,'hand':h['handNumber'],'player':p['playerId'],'kind':kind,'show':show,'folded':p['folded'],'won':won,'opening':opening,'net':p['netChips'],'cards':[c['id'] for c in p['cards']],'rivals':[{'id':q['playerId'],'kind':q['score']['combinations'][0]['kind'] if q['score']['combinations'] else 'high-card','rank':q['score']['total']} for q in rivals],'bets':h['bettingHistory']}
      cases.append(case)
   for g in run.get('games',[]):
    totals['constituentGames']+=1;totals['loans']+=sum(p['loans'] for p in g['players']);totals['endingSticksSum']+=sum(p['riichiSticks'] for p in g['players'])
  summary[f'{arm}-{fmt}']={'totals':dict(totals),'rows':dict(rows)};examples.extend(cases)
(root/'analysis.json').write_text(json.dumps(summary,indent=2));(root/'twin-cases.json').write_text(json.dumps(examples,indent=2))
print(json.dumps({k:v['totals'] for k,v in summary.items()},indent=2))
