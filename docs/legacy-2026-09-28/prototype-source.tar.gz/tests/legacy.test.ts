import { describe, expect, it } from "vitest"
import { createDeck, numberedFace, dragonFace, faceKey, jokerCanRepresent } from "../src/game/cards"
import { scoreHand, compareHandStrengths } from "../src/game/scoring"
import { SeededRandom } from "../src/game/random"
import { SUITS, DRAGONS, type Card } from "../src/game/types"
import { legacyDeck, isTreasure, treasureCount } from "../scripts/legacy/cards"
import { evaluateLegacy, LEGACY_LADDER } from "../scripts/legacy/scoring"
import { LegacyEngine } from "../scripts/legacy/engine"
import { botView, stepLegacy } from "../scripts/legacy/bots"

const deck = legacyDeck()
function cards(...ids: string[]): Card[] {
  return ids.map((id) => {
    const card = deck.find((candidate) => candidate.id === id)
    if (!card) throw new Error(id)
    return card
  })
}
function engine(players = 4, overrides = {}) {
  return LegacyEngine.createLegacy({
    seed: "legacy-test",
    players,
    orbits: 2,
    treasureAnte: 4,
    treasureSets: false,
    ...overrides,
  })
}
function give(game: LegacyEngine, seat: number, id: string) {
  const own = game.state.players[seat].privateCards
  if (own.some((c) => c.id === id)) return
  const pools = [...game.decks, ...game.lanes, ...game.state.players.map((p) => p.privateCards)]
  const pool = pools.find((p) => p.some((c) => c.id === id))!
  const index = pool.findIndex((c) => c.id === id)
  const replace = own.findIndex((c) => !isTreasure(c))
  ;[own[replace], pool[index]] = [pool[index], own[replace]]
}
function open(game: LegacyEngine) {
  for (const p of game.state.players)
    game.passCharleston(
      p.id,
      p.privateCards.slice(0, 2).map((c) => c.id),
    )
}

describe("Legacy evaluator", () => {
  it("agrees with exhaustive suit assignments for wild hands", () => {
    const random = new SeededRandom("wild-reference")
    for (let sample = 0; sample < 400; sample++) {
      const hand = random.shuffle(deck).slice(0, 7)
      let reference = { total: 0, tieBreak: [] as number[] }
      const expand = (index: number, assigned: Card[]) => {
        if (index < hand.length) {
          const card = hand[index]
          if (!card.id.startsWith("wild-")) return expand(index + 1, [...assigned, card])
          const variants =
            card.kind === "numbered"
              ? SUITS.map((suit) => ({ ...numberedFace(suit, card.rank), id: card.id }))
              : DRAGONS.map((dragon) => ({ ...dragonFace(dragon), id: card.id }))
          for (const variant of variants) expand(index + 1, [...assigned, variant])
          return
        }
        const scored = scoreHand(assigned)
        let candidate = {
          total: LEGACY_LADDER.indexOf(scored.combinations[0]?.kind ?? "high-card") + 1,
          tieBreak: scored.tieBreak,
        }
        for (const target of assigned.filter((card) =>
          ["numbered", "wind", "dragon"].includes(card.kind),
        )) {
          if (
            assigned.filter(
              (card) => faceKey(card) === faceKey(target) || jokerCanRepresent(card, target),
            ).length >= 5
          ) {
            const value =
              target.kind === "wind"
                ? 11
                : target.kind === "dragon"
                  ? 10
                  : target.kind === "numbered"
                    ? target.rank
                    : 0
            const quint = {
              total: LEGACY_LADDER.indexOf("quint") + 1,
              tieBreak: Array<number>(5).fill(value),
            }
            if (compareHandStrengths(quint, candidate) > 0) candidate = quint
          }
        }
        if (compareHandStrengths(candidate, reference) > 0) reference = candidate
      }
      expand(0, [])
      expect(compareHandStrengths(evaluateLegacy(hand), reference)).toBe(0)
    }
  })
  it("matches v6 Riichi categories and tie breaks on ordinary cards", () => {
    const random = new SeededRandom("legacy-equivalence")
    for (let i = 0; i < 1000; i++) {
      const hand = random.shuffle(createDeck("riichi")).slice(0, 7)
      const base = scoreHand(hand),
        actual = evaluateLegacy(hand)
      const kind = base.combinations[0]?.kind ?? "high-card"
      expect(actual.kind).toBe(kind)
      expect(actual.tieBreak).toEqual(base.tieBreak)
    }
  })
  it("keeps wild numbers fixed and allows wild pairs", () => {
    expect(evaluateLegacy(cards("wild-5", "dots-5-1")).kind).toBe("eye")
    expect(evaluateLegacy(cards("wild-5", "dots-6-1")).kind).toBe("high-card")
    expect(evaluateLegacy(cards("wild-5", "dots-4-1", "dots-6-1")).kind).toBe("chow")
    expect(evaluateLegacy(cards("wild-5", "wind-east-1")).kind).toBe("high-card")
  })
  it("handles wild Dragons and ranks Quints above Kongs", () => {
    expect(evaluateLegacy(cards("wild-dragon", "dragon-red-1", "dragon-white-1")).kind).toBe(
      "three-dragons",
    )
    const kong = evaluateLegacy(cards("bamboo-5-1", "bamboo-5-2", "bamboo-5-3", "wild-5"))
    const quint = evaluateLegacy(
      cards("bamboo-5-1", "bamboo-5-2", "bamboo-5-3", "wild-5", "joker-green"),
    )
    expect(kong.kind).toBe("kong")
    expect(quint.kind).toBe("quint")
    expect(compareHandStrengths(quint, kong)).toBeGreaterThan(0)
    expect(
      evaluateLegacy(
        cards("wind-east-1", "wind-east-2", "wind-east-3", "wind-east-4", "joker-black"),
      ).kind,
    ).toBe("quint")
  })
  it("does not reuse a wildcard between a pair and a meld", () => {
    const hand = cards("dots-4-1", "dots-6-1", "wild-5", "bamboo-5-1", "blank-1")
    expect(evaluateLegacy(hand).kind).toBe("chow")
    expect(evaluateLegacy(cards("joker-blue", "dots-5-1")).kind).toBe("high-card")
  })
  it("scores Treasures only as optional distinct sets", () => {
    const treasures = cards("treasure-1", "treasure-2", "treasure-3", "treasure-4")
    expect(evaluateLegacy(treasures).kind).toBe("high-card")
    expect(evaluateLegacy(treasures, true).kind).toBe("four-treasures")
    expect(evaluateLegacy(treasures.slice(0, 3), true).kind).toBe("three-treasures")
    expect(LEGACY_LADDER.indexOf("four-treasures")).toBeGreaterThan(LEGACY_LADDER.indexOf("kong"))
    expect(LEGACY_LADDER.indexOf("four-treasures")).toBeLessThan(LEGACY_LADDER.indexOf("quint"))
  })
})

describe("Legacy physical rules", () => {
  it("allows the proposed unavailable-fish exception without drawing from another deck", () => {
    const game = engine(4, { skipUnavailableFish: true })
    open(game)
    const actor = game.seat(game.state.actingPlayerId!),
      target = (actor + 1) % 4
    const player = game.state.players[actor]
    game.decks[target].push(...game.decks[actor].splice(0), ...game.lanes.flat())
    for (const lane of game.lanes) lane.splice(0)
    for (const [index, card] of player.privateCards.entries()) {
      if (!isTreasure(card)) continue
      const replacement = game.decks[target].findIndex((candidate) => candidate.kind === "numbered")
      ;[player.privateCards[index], game.decks[target][replacement]] = [
        game.decks[target][replacement],
        card,
      ]
    }
    const oldHand = [...player.privateCards]
    const oldDecks = game.decks.map((d) => d.length)
    game.actWithFish(player.id, { type: "check" }, [])
    expect(player.privateCards).toEqual(oldHand)
    expect(game.decks.map((d) => d.length)).toEqual(oldDecks)
    expect(game.state.pendingDiscard).toBeNull()
    expect(game.state.actingPlayerId).not.toBe(player.id)
    game.assertCards()
  })
  it("allows a Blank to take a buried card in the player's own lane", () => {
    const game = engine()
    open(game)
    const actor = game.seat(game.state.actingPlayerId!)
    give(game, actor, "blank-1")
    game.lanes[actor].push(game.decks[(actor + 1) % 4].pop()!)
    const taken = game.lanes[actor][0]
    const deckSizes = game.decks.map((d) => d.length)
    game.actWithFish(game.state.players[actor].id, { type: "check" }, [
      { kind: "blank", cardId: "blank-1", lane: actor, index: 0 },
    ])
    expect(game.lanes[actor][0].id).toBe("blank-1")
    expect(game.state.players[actor].privateCards.some((card) => card.id === taken.id)).toBe(true)
    expect(game.decks.map((d) => d.length)).toEqual(deckSizes)
    expect(game.state.pendingDiscard).toBeNull()
    game.assertCards()
  })
  it("tests the proposed seven-card seed exception without losing cards", () => {
    const game = engine(4, { shortDeck: "skip-seed" })
    game.decks[1].push(...game.decks[0].splice(0), ...game.lanes[0].splice(0))
    game.state.phase = "between-hands"
    game.startNextHand()
    expect(game.state.players[0].privateCards.length).toBe(7)
    expect(game.decks[0].length).toBe(0)
    expect(game.lanes.flat().length).toBe(3)
    game.assertCards()
  })
  it.each([2, 3, 4, 5, 6])("splits evenly, deals eight and seeds left at %i players", (count) => {
    const game = engine(count)
    expect(game.reserve.length).toBe(132 % count)
    expect(new Set(game.deckSizes[0]).size).toBe(1)
    expect(game.state.players.every((p) => p.privateCards.length === 7)).toBe(true)
    expect(game.lanes.every((lane) => lane.length === 1)).toBe(true)
    game.assertCards()
  })
  it("discards into a neighbor's lane, which joins that neighbor's deck next round", () => {
    const game = engine()
    open(game)
    const actor = game.seat(game.state.actingPlayerId!),
      id = game.state.players[actor].id
    game.actWithFish(id, { type: "check" }, [{ kind: "draw", source: "deck" }])
    const discarded = game.state.players[actor].privateCards[0]
    const owner = game.neighbor(actor, "b")
    game.discard(id, { discardCardId: discarded.id, discardPile: "b" })
    expect(game.lanes[owner].at(-1)?.id).toBe(discarded.id)
    while (game.state.phase === "betting")
      game.actWithFish(game.state.actingPlayerId!, { type: "fold" }, [])
    game.startNextHand()
    // The next eight-card deal and seed may move it again; verify it belonged to
    // the recipient's shuffled deck by the known-deck memory or opening cards.
    const known = game.knownDecks[owner].has(discarded.id)
    const opening = game.state.openingPrivateCards[game.state.players[owner].id].some(
      (c) => c.id === discarded.id,
    )
    const seeded = game.lanes[game.neighbor(owner, "a")].some((c) => c.id === discarded.id)
    expect(known || opening || seeded).toBe(true)
    game.assertCards()
  })
  it("exchanges Treasures without drawing, discarding, or taking public cards", () => {
    const game = engine()
    open(game)
    const actor = game.seat(game.state.actingPlayerId!),
      target = (actor + 2) % 4
    give(game, actor, "treasure-1")
    const p = game.state.players[actor],
      q = game.state.players[target]
    q.publicCards.push(q.privateCards.pop()!)
    const protectedId = q.publicCards[0].id
    const oldSizes = game.decks.map((d) => d.length),
      lanes = game.lanes.flat().map((c) => c.id)
    game.actWithFish(p.id, { type: "check" }, [{ kind: "treasure", cardId: "treasure-1", target }])
    expect(p.privateCards.length).toBe(7)
    expect(q.privateCards.length).toBe(6)
    expect(q.privateCards.some((c) => c.id === "treasure-1")).toBe(true)
    expect(q.publicCards[0].id).toBe(protectedId)
    expect(game.decks.map((d) => d.length)).toEqual(oldSizes)
    expect(game.lanes.flat().map((c) => c.id)).toEqual(lanes)
    expect(game.state.pendingDiscard).toBeNull()
    game.assertCards()
  })
  it("rejects exchanges into Riichi locks atomically", () => {
    const game = engine()
    open(game)
    const actor = game.seat(game.state.actingPlayerId!),
      target = (actor + 1) % 4
    give(game, actor, "treasure-1")
    game.state.players[target].riichi = true
    const before = JSON.stringify({ state: game.state, decks: game.decks, lanes: game.lanes })
    expect(() =>
      game.actWithFish(game.state.players[actor].id, { type: "check" }, [
        { kind: "treasure", cardId: "treasure-1", target },
      ]),
    ).toThrow("Invalid Treasure target")
    expect(JSON.stringify({ state: game.state, decks: game.decks, lanes: game.lanes })).toBe(before)
    game.assertCards()
  })
  it("pays showdown Treasures, including losing hands, and conserves reserve-adjusted chips", () => {
    const game = engine()
    open(game)
    const actor = game.seat(game.state.actingPlayerId!)
    give(game, actor, "treasure-1")
    const holder = game.state.players[actor]
    // An all-in bet skips the remaining streets and preserves Treasure holdings.
    game.actWithFish(holder.id, { type: "bet", amount: holder.chips }, [])
    while (game.state.phase === "betting" || game.state.phase === "discarding") {
      if (game.state.phase === "betting")
        game.actWithFish(game.state.actingPlayerId!, { type: "call" }, [
          { kind: "draw", source: "deck" },
        ])
      else {
        const id = game.state.pendingDiscard!.playerId
        game.discard(id, {
          discardCardId: game.state.pendingDiscard!.drawnCardId,
          discardPile: "a",
        })
      }
    }
    const result = game.state.handResults.at(-1)!
    const expected = result.players
      .filter((p) => !p.folded)
      .reduce((sum, p) => sum + treasureCount(p.cards) * 20, 0)
    expect(game.bonuses.reduce((sum, b) => sum + b.amount, 0)).toBe(expected)
    expect(expected).toBeGreaterThanOrEqual(20)
    expect(game.state.players.reduce((sum, p) => sum + p.chips, 0)).toBeCloseTo(800 + expected)
    expect(result.reason).toBe("showdown")
    game.assertCards()
  })
  it("keeps bots blind to concealed cards and deck order", () => {
    const game = engine()
    open(game)
    const seat = game.seat(game.state.actingPlayerId!),
      before = botView(game, seat)
    const opponent = (seat + 1) % 4
    game.decks[seat].reverse()
    const hidden = game.state.players[opponent].privateCards
    ;[hidden[0], game.decks[opponent][0]] = [game.decks[opponent][0], hidden[0]]
    expect(botView(game, seat)).toEqual(before)
  })
  it("runs deterministically across rounds with all physical cards preserved", () => {
    const run = () => {
      const game = engine(4, { orbits: 1 })
      for (let i = 0; game.state.phase !== "finished" && i < 1000; i++) stepLegacy(game, 4, [])
      expect(game.state.phase).toBe("finished")
      game.assertCards()
      const emitted = game.bonuses.reduce((sum, b) => sum + b.amount, 0)
      const loans = game.state.players.reduce((sum, p) => sum + p.loans * 200, 0)
      expect(game.state.players.reduce((sum, p) => sum + p.chips, 0)).toBeCloseTo(
        800 + emitted + loans,
      )
      return { scores: game.state.finalScores, events: game.events, deckSizes: game.deckSizes }
    }
    expect(run()).toEqual(run())
  }, 30_000)
})
