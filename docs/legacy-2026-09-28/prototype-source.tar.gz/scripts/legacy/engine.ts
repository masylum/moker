import { GameEngine } from "../../src/game/engine"
import type {
  BettingAction,
  BlankExchange,
  Card,
  CardSource,
  DiscardPile,
  DrawContext,
  GameEvent,
  GameState,
  HandResult,
  PlayerState,
} from "../../src/game/types"
import { legacyDeck, isBlank, isTreasure, treasureCount } from "./cards"
import { evaluateLegacy } from "./scoring"

export interface LegacyOptions {
  seed: string
  players: number
  orbits: number
  games?: 1 | 2 | 3 | 4
  treasureAnte: number
  treasureSets: boolean
  exchangePolicy?: "strategic" | "hold" | "exchange"
  policies?: ("strategic" | "hold" | "exchange")[]
  checkdown?: boolean
  shortDeck?: "stop" | "skip-seed"
  skipUnavailableFish?: boolean
}
export type FishPlan =
  | { kind: "draw"; source: CardSource }
  | { kind: "blank"; cardId: string; lane: number; index: number }
  | { kind: "treasure"; cardId: string; target: number }
export interface ExchangeAudit {
  hand: number
  street: number
  actor: number
  target: number
  reason: string
  actorBefore: string[]
  actorAfter: string[]
  targetBefore: string[]
  targetAfter: string[]
  drawn: string
  given: string
  targetHiddenCount: number
}
export class DeckExhausted extends Error {}

/** Experimental headless adapter. Production UI/API cannot select this class. */
export class LegacyEngine extends GameEngine {
  readonly options: LegacyOptions
  readonly decks: Card[][]
  readonly lanes: Card[][]
  readonly reserve: Card[]
  readonly allCards = legacyDeck()
  readonly knownDecks: Set<string>[]
  readonly knownHands: Map<string, Set<string>>[]
  readonly exchanges: ExchangeAudit[] = []
  readonly deckSizes: number[][] = []
  readonly bonuses: { hand: number; player: number; amount: number }[] = []
  readonly drawCounts = { deck: 0, lane: 0, blank: 0, treasure: 0 }
  private plans: FishPlan[] = []
  private allocated = false

  private constructor(state: GameState, events: GameEvent[], options: LegacyOptions) {
    super(state, events)
    this.options = options
    const shuffled = this.random.shuffle(this.allCards)
    this.reserve = shuffled.splice(0, shuffled.length % options.players)
    const count = shuffled.length / options.players
    this.decks = Array.from({ length: options.players }, (_, i) =>
      shuffled.slice(i * count, (i + 1) * count),
    )
    this.lanes = Array.from({ length: options.players }, () => [])
    this.knownDecks = Array.from({ length: options.players }, () => new Set<string>())
    this.knownHands = Array.from({ length: options.players }, () => new Map<string, Set<string>>())
  }

  static createLegacy(options: LegacyOptions): LegacyEngine {
    return GameEngine.create(
      Array.from({ length: options.players }, (_, i) => ({
        name: i === 0 ? "legacy" : `Bot ${i + 1}`,
        controller: "heuristic" as const,
      })),
      {
        seed: options.seed,
        mode: "riichi",
        orbits: options.orbits,
        tournamentGames: options.games ?? 1,
      },
      (state, events) => new LegacyEngine(state, events, options),
    ) as LegacyEngine
  }

  seat(playerId: string): number {
    const index = this.state.players.findIndex((p) => p.id === playerId)
    if (index < 0) throw new Error("Unknown Legacy player")
    return index
  }

  neighbor(seat: number, direction: DiscardPile): number {
    return (seat + (direction === "a" ? 1 : this.decks.length - 1)) % this.decks.length
  }

  override passCharleston(playerId: string, cardIds: string[]): void {
    const before = this.state.charlestonHistory.length
    super.passCharleston(playerId, cardIds)
    for (const pass of this.state.charlestonHistory.slice(before)) {
      this.remember(pass.fromPlayerId, pass.toPlayerId, pass.cards)
    }
  }

  private remember(observer: string, owner: string, cards: Card[]): void {
    const map = this.knownHands[this.seat(observer)]
    const ids = map.get(owner) ?? new Set<string>()
    for (const card of cards) ids.add(card.id)
    map.set(owner, ids)
  }

  private forget(cardId: string): void {
    for (const observer of this.knownHands) for (const ids of observer.values()) ids.delete(cardId)
  }

  actWithFish(playerId: string, action: BettingAction, plans: FishPlan[]): void {
    // Keep the core action's transaction atomic for experimental state as well.
    const extras = structuredClone({
      decks: this.decks,
      lanes: this.lanes,
      knownDecks: this.knownDecks,
      knownHands: this.knownHands,
      draws: this.drawCounts,
      exchanges: this.exchanges,
      bonuses: this.bonuses,
    })
    this.plans = [...plans]
    const converted = { ...action }
    if (converted.type !== "fold") {
      plans.forEach((plan, index) => {
        const source = plan.kind === "draw" ? plan.source : "deck"
        const exchange =
          plan.kind === "draw"
            ? undefined
            : { blankCardId: plan.cardId, pile: "a" as const, cardIndex: 0 }
        if (index === 0) {
          converted.drawSource = source
          converted.blankExchange = exchange
        } else if (converted.type !== "bet") {
          converted.riichiDrawSource = source
          converted.riichiBlankExchange = exchange
        }
      })
    }
    try {
      super.act(playerId, converted)
    } catch (error) {
      this.decks.splice(0, this.decks.length, ...extras.decks)
      this.lanes.splice(0, this.lanes.length, ...extras.lanes)
      this.knownDecks.splice(0, this.knownDecks.length, ...extras.knownDecks)
      this.knownHands.splice(0, this.knownHands.length, ...extras.knownHands)
      Object.assign(this.drawCounts, extras.draws)
      this.exchanges.splice(0, this.exchanges.length, ...extras.exchanges)
      this.bonuses.splice(0, this.bonuses.length, ...extras.bonuses)
      throw error
    } finally {
      this.plans = []
    }
  }

  override discard(
    playerId: string,
    decision: { discardCardId: string; discardPile: DiscardPile },
  ): void {
    const pending = this.state.pendingDiscard
    if (!pending) throw new Error("No pending discard")
    const player = this.state.players[this.seat(playerId)]
    const drawn = player.privateCards.find((c) => c.id === pending.drawnCardId)!
    super.discard(playerId, decision)
    this.forget(decision.discardCardId)
    if (pending.source !== "deck" && drawn.id !== decision.discardCardId)
      for (const observer of this.state.players) this.remember(observer.id, playerId, [drawn])
    this.assertCards()
  }

  override exposeCards(playerId: string, cardIds: string[]): void {
    super.exposeCards(playerId, cardIds)
    // Until simultaneous reveal finishes, selections are private.
    if (this.state.phase !== "exposing")
      for (const player of this.state.players)
        for (const card of player.publicCards) this.forget(card.id)
  }

  protected override prepareRound(): void {
    if (!this.allocated) {
      this.allocated = true
      this.deckSizes.push(this.decks.map((d) => d.length))
      return
    }
    for (const [i, player] of this.state.players.entries()) {
      const cards = [
        ...(this.state.foldedPrivateCards[player.id] ?? player.privateCards),
        ...player.publicCards,
        ...this.lanes[i],
      ]
      for (const card of cards) this.knownDecks[i].add(card.id)
      this.decks[i] = this.random.shuffle([...this.decks[i], ...cards])
      this.lanes[i] = []
      this.knownHands[i].clear()
    }
    this.deckSizes.push(this.decks.map((d) => d.length))
  }

  protected override hasFishingSource(player: PlayerState): boolean {
    if (!this.options.skipUnavailableFish) return true
    const seat = this.seat(player.id)
    return Boolean(
      this.decks[seat].length ||
      this.lanes[this.neighbor(seat, "a")].length ||
      this.lanes[this.neighbor(seat, "b")].length ||
      (player.privateCards.some(isBlank) && this.lanes.some((lane) => lane.length)) ||
      (player.privateCards.some(isTreasure) &&
        this.state.players.some(
          (target) =>
            target.id !== player.id &&
            !target.folded &&
            !target.eliminated &&
            !target.riichi &&
            target.privateCards.length,
        )),
    )
  }

  protected override createRoundDeck(): Card[] {
    return []
  }
  protected override seedLanes(): void {}
  protected override requiresEmptyLaneFill(): boolean {
    return false
  }

  protected override dealOpeningCards(players: PlayerState[]): void {
    for (const player of players) {
      const seat = this.seat(player.id)
      const dealCount =
        this.options.shortDeck === "skip-seed" && this.decks[seat].length === 7 ? 7 : 8
      if (this.decks[seat].length < dealCount)
        throw new DeckExhausted(
          `${player.id} has ${this.decks[seat].length} cards before round ${this.state.handNumber}`,
        )
      for (let i = 0; i < dealCount; i++) {
        const card = this.decks[seat].pop()!
        this.knownDecks[seat].delete(card.id)
        player.privateCards.push(card)
      }
    }
    // Commit all seed choices before any seed is exposed.
    const seeds = players
      .filter((player) => player.privateCards.length === 8)
      .map((player) => {
        let best = 0,
          bestValue = -Infinity
        player.privateCards.forEach((_card, index) => {
          const kept = player.privateCards.filter((_, i) => i !== index)
          const score = evaluateLegacy(kept, this.options.treasureSets)
          const value =
            score.total +
            treasureCount(kept) * this.options.treasureAnte * 0.4 -
            (kept.filter((c) => c.kind === "flower").length === 1 ? 5 : 0)
          if (value > bestValue) {
            bestValue = value
            best = index
          }
        })
        return { player, index: best }
      })
    for (const { player, index } of seeds)
      this.lanes[this.neighbor(this.seat(player.id), "a")].push(
        player.privateCards.splice(index, 1)[0],
      )
    this.assertCards()
  }

  protected override lane(pile: DiscardPile): Card[] {
    if (!this.state.actingPlayerId) throw new Error("Lane access requires an actor")
    return this.lanes[this.neighbor(this.seat(this.state.actingPlayerId), pile)]
  }

  protected override drawPile(player: PlayerState, source: CardSource): Card[] {
    const seat = this.seat(player.id)
    const pile =
      source === "deck"
        ? this.decks[seat]
        : this.lanes[this.neighbor(seat, source === "discard-a" ? "a" : "b")]
    if (!pile.length) throw new DeckExhausted(`Empty ${source} for ${player.id}`)
    const card = pile.at(-1)!
    if (source === "deck") this.knownDecks[seat].delete(card.id)
    this.drawCounts[source === "deck" ? "deck" : "lane"]++
    // Plans are needed only for exchange instructions. The simulator never queues
    // a second fish: a stick buys one fish on a bet, avoiding stale second plans.
    return pile
  }

  protected override exchangeBlank(
    player: PlayerState,
    exchange: BlankExchange,
    reason: DrawContext["reason"],
  ): void {
    if (player.riichi) throw new Error("Riichi locks fishing")
    const plan = this.plans.shift()
    if (!plan || plan.kind === "draw" || plan.cardId !== exchange.blankCardId)
      throw new Error("Missing exchange plan")
    const index = player.privateCards.findIndex((c) => c.id === plan.cardId)
    if (index < 0) throw new Error("Exchange requires a concealed card")
    const card = player.privateCards[index]
    const actor = this.seat(player.id)
    if (plan.kind === "blank") {
      if (!isBlank(card)) throw new Error("Not a Blank")
      const lane = this.lanes[plan.lane]
      const target = lane?.[plan.index]
      if (!target) throw new Error("No lane card")
      lane[plan.index] = card
      player.privateCards[index] = target
      this.forget(card.id)
      for (const observer of this.state.players) this.remember(observer.id, player.id, [target])
      this.drawCounts.blank++
      this.emit(
        "legacy-blank",
        { actor, lane: plan.lane, index: plan.index, given: card.id, taken: target.id, reason },
        player.id,
      )
    } else {
      if (!isTreasure(card) || actor === plan.target) throw new Error("Invalid Treasure")
      const target = this.state.players[plan.target]
      if (
        !target ||
        target.folded ||
        target.eliminated ||
        target.riichi ||
        !target.privateCards.length
      )
        throw new Error("Invalid Treasure target")
      const targetIndex = this.random.integer(target.privateCards.length)
      const taken = target.privateCards[targetIndex]
      const audit: ExchangeAudit = {
        hand: this.state.handNumber,
        street: this.state.street,
        actor,
        target: plan.target,
        reason,
        actorBefore: [...player.privateCards, ...player.publicCards].map((c) => c.id),
        actorAfter: [],
        targetBefore: [...target.privateCards, ...target.publicCards].map((c) => c.id),
        targetAfter: [],
        drawn: taken.id,
        given: card.id,
        targetHiddenCount: target.privateCards.length,
      }
      target.privateCards[targetIndex] = card
      player.privateCards[index] = taken
      // Outsiders cannot know which concealed card left the target.
      for (const observer of this.knownHands) observer.delete(target.id)
      this.forget(card.id)
      for (const observer of this.state.players) this.remember(observer.id, target.id, [card])
      this.remember(target.id, player.id, [taken])
      audit.actorAfter = [...player.privateCards, ...player.publicCards].map((c) => c.id)
      audit.targetAfter = [...target.privateCards, ...target.publicCards].map((c) => c.id)
      this.exchanges.push(audit)
      this.drawCounts.treasure++
      this.emit(
        "legacy-treasure",
        { actor, target: plan.target, given: card.id, reason },
        player.id,
      )
    }
    this.assertCards()
  }

  protected override scoreCards(cards: Card[]) {
    return evaluateLegacy(cards, this.options.treasureSets)
  }

  protected override settleRoundBonus(reason: HandResult["reason"]): void {
    if (reason !== "showdown") return
    for (const [i, player] of this.state.players.entries()) {
      if (player.folded || player.eliminated) continue
      const amount =
        treasureCount([...player.privateCards, ...player.publicCards]) *
        this.options.treasureAnte *
        this.state.orbitValue
      if (!amount) continue
      player.chips += amount
      this.bonuses.push({ hand: this.state.handNumber, player: i, amount })
      this.emit("legacy-treasure-bonus", { amount }, player.id)
    }
  }

  assertCards(): void {
    const physical = [
      ...this.reserve,
      ...this.decks.flat(),
      ...this.lanes.flat(),
      ...this.state.players.flatMap((p) => [
        ...(this.state.foldedPrivateCards[p.id] ?? p.privateCards),
        ...p.publicCards,
      ]),
    ]
    if (physical.length !== 132 || new Set(physical.map((c) => c.id)).size !== 132)
      throw new Error("Legacy physical-card conservation failed")
  }
}
