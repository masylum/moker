import { SeededRandom } from "../../src/game/random"
import { compareHandStrengths } from "../../src/game/scoring"
import { STREET_REVEAL_COUNTS } from "../../src/game/rules"
import type { BettingAction, Card, DiscardPile } from "../../src/game/types"
import { identities, isBlank, isTreasure, isWild, lotusCount, treasureCount } from "./cards"
import { LegacyEngine, type FishPlan } from "./engine"
import { evaluateLegacy } from "./scoring"

interface OpponentView {
  seat: number
  id: string
  publicCards: Card[]
  hiddenCount: number
  known: Card[]
  riichi: boolean
}
export interface BotView {
  seat: number
  id: string
  hand: Card[]
  publicCards: Card[]
  opponents: OpponentView[]
  lanes: Card[][]
  left: number
  right: number
  deckCount: number
  knownDeck: Card[]
  unknown: Card[]
  ante: number
  pot: number
  street: number
  treasureAnte: number
  treasureSets: boolean
}
interface World {
  hands: Map<number, Card[]>
  deckDraw: Card
  targetIndex: Map<number, number>
}
interface PlanValue {
  plan: FishPlan
  utility: number
  equity: number
  bonus: number
}
export interface TreasureOpportunity {
  street: number
  actor: number
  chosen: string
  treasureCount: number
  options: PlanValue[]
  damagedFraction: number
  eligibleHiddenCards: number
}

/** This is the only input to the policy evaluator. No concealed opponent cards,
 * true deck order, reserve identities, or full engine state cross this boundary. */
export function botView(engine: LegacyEngine, seat: number): BotView {
  const state = engine.state,
    player = state.players[seat]
  const allById = new Map(engine.allCards.map((c) => [c.id, c]))
  const opponents = state.players.flatMap((p, i) =>
    i === seat || p.folded || p.eliminated
      ? []
      : [
          {
            seat: i,
            id: p.id,
            publicCards: [...p.publicCards],
            hiddenCount: p.privateCards.length,
            known: [...(engine.knownHands[seat].get(p.id) ?? [])].map((id) => allById.get(id)!),
            riichi: p.riichi,
          },
        ],
  )
  const knownDeck = [...engine.knownDecks[seat]].map((id) => allById.get(id)!)
  const visible = new Set(
    [
      ...player.privateCards,
      ...state.players.flatMap((p) => p.publicCards),
      ...engine.lanes.flat(),
      ...opponents.flatMap((p) => p.known),
      ...knownDeck,
    ].map((c) => c.id),
  )
  // Reserve and unseen folded hands remain in the uncertainty pool.
  return {
    seat,
    id: player.id,
    hand: [...player.privateCards],
    publicCards: [...player.publicCards],
    opponents,
    lanes: engine.lanes.map((lane) => [...lane]),
    left: engine.neighbor(seat, "a"),
    right: engine.neighbor(seat, "b"),
    deckCount: engine.decks[seat].length,
    knownDeck,
    unknown: engine.allCards.filter((c) => !visible.has(c.id)),
    ante: state.orbitValue,
    pot: state.pot,
    street: state.street,
    treasureAnte: engine.options.treasureAnte,
    treasureSets: engine.options.treasureSets,
  }
}

function sampleWorlds(view: BotView, samples: number, random: SeededRandom): World[] {
  return Array.from({ length: samples }, () => {
    const unknown = random.shuffle(view.unknown)
    const hands = new Map<number, Card[]>(),
      targetIndex = new Map<number, number>()
    for (const opponent of view.opponents) {
      const missing = Math.max(0, opponent.hiddenCount - opponent.known.length)
      const hidden = [...opponent.known, ...unknown.splice(0, missing)]
      hands.set(opponent.seat, hidden)
      targetIndex.set(opponent.seat, random.integer(Math.max(1, hidden.length)))
    }
    const drawKnown =
      view.knownDeck.length > 0 &&
      random.next() < view.knownDeck.length / Math.max(1, view.deckCount)
    const deckDraw = drawKnown
      ? random.pick(view.knownDeck)
      : (unknown[0] ?? view.unknown[0] ?? view.knownDeck[0])
    if (!deckDraw) throw new Error("Empty belief draw pool")
    return { hands, deckDraw, targetIndex }
  })
}

/** Small tie-breaking development term, not a learned policy or solved game. */
function shape(cards: Card[]): number {
  const counts = Array<number>(34).fill(0)
  for (const card of cards) for (const identity of identities(card, false)) counts[identity]++
  let value = 0
  for (let i = 0; i < 34; i++) {
    value += Math.max(0, counts[i] - 1) * 0.3
    if (i < 27 && i % 9 < 8) value += Math.min(counts[i], counts[i + 1]) * 0.1
  }
  value += cards.filter((c) => isWild(c) || c.kind === "joker").length * 0.12
  return value
}

function handUtility(cards: Card[], treasureAnte: number, sets: boolean): number {
  const lotus = lotusCount(cards)
  return (
    (lotus === 1 ? 0 : evaluateLegacy(cards, sets).total) +
    shape(cards) +
    treasureCount(cards) * treasureAnte * 0.4
  )
}

function keepAfterDraw(view: BotView, drawn: Card): Card[] {
  const hand = [...view.hand, drawn]
  let best = hand.slice(0, -1),
    value = -Infinity
  for (let index = 0; index < hand.length; index++) {
    const kept = hand.filter((_, i) => i !== index)
    const current = handUtility(
      [...kept, ...view.publicCards],
      view.treasureAnte,
      view.treasureSets,
    )
    if (current > value) {
      best = kept
      value = current
    }
  }
  return best
}

function equity(
  view: BotView,
  own: Card[],
  world: World,
  changedTarget?: { seat: number; hidden: Card[] },
): number {
  const hands = [
    { seat: view.seat, cards: [...own, ...view.publicCards] },
    ...view.opponents.map((opponent) => ({
      seat: opponent.seat,
      cards: [
        ...opponent.publicCards,
        ...(changedTarget?.seat === opponent.seat
          ? changedTarget.hidden
          : world.hands.get(opponent.seat)!),
      ],
    })),
  ]
  const eligible = hands.filter((h) => lotusCount(h.cards) !== 1)
  if (!eligible.length) return 1 / hands.length
  const mine = eligible.find((h) => h.seat === view.seat)
  if (!mine) return 0
  const score = evaluateLegacy(mine.cards, view.treasureSets)
  let tied = 1
  for (const hand of eligible) {
    if (hand.seat === view.seat) continue
    const compared = compareHandStrengths(evaluateLegacy(hand.cards, view.treasureSets), score)
    if (compared > 0) return 0
    if (compared === 0) tied++
  }
  return 1 / tied
}

function valuePlan(
  view: BotView,
  plan: FishPlan | undefined,
  worlds: World[],
  pot: number,
): PlanValue {
  let equitySum = 0,
    bonusSum = 0,
    development = 0
  for (const world of worlds) {
    let hand = view.hand,
      changed: { seat: number; hidden: Card[] } | undefined
    if (plan?.kind === "draw") {
      const card =
        plan.source === "deck"
          ? world.deckDraw
          : view.lanes[plan.source === "discard-a" ? view.left : view.right].at(-1)!
      hand = keepAfterDraw(view, card)
    } else if (plan?.kind === "blank") {
      const card = view.lanes[plan.lane][plan.index]
      hand = view.hand.map((c) => (c.id === plan.cardId ? card : c))
    } else if (plan?.kind === "treasure") {
      const target = [...world.hands.get(plan.target)!]
      const targetIndex = world.targetIndex.get(plan.target)!
      const card = target[targetIndex]
      target[targetIndex] = view.hand.find((c) => c.id === plan.cardId)!
      changed = { seat: plan.target, hidden: target }
      hand = view.hand.map((c) => (c.id === plan.cardId ? card : c))
    }
    equitySum += equity(view, hand, world, changed)
    bonusSum += treasureCount([...hand, ...view.publicCards]) * view.treasureAnte * view.ante
    development += shape([...hand, ...view.publicCards]) * view.ante * 0.15 * (4 - view.street)
  }
  const eq = equitySum / worlds.length,
    bonus = bonusSum / worlds.length
  // Expected bonus conditional on reaching showdown; early-street survival is
  // uncertain, so use an explicit sensitivity-testable discount.
  const survival = view.street === 4 ? 1 : 0.65 + 0.1 * (view.street - 1)
  return {
    plan: plan ?? { kind: "draw", source: "deck" },
    equity: eq,
    bonus,
    utility: eq * pot + bonus * survival + development / worlds.length,
  }
}

function chooseFishing(
  view: BotView,
  samples: number,
  seed: string,
  policy: "strategic" | "hold" | "exchange" = "strategic",
  pot = view.pot,
) {
  const worlds = sampleWorlds(view, samples, new SeededRandom(seed))
  const plans: FishPlan[] = []
  if (view.deckCount) plans.push({ kind: "draw", source: "deck" })
  if (view.lanes[view.left].length) plans.push({ kind: "draw", source: "discard-a" })
  if (view.right !== view.left && view.lanes[view.right].length)
    plans.push({ kind: "draw", source: "discard-b" })
  const blank = view.hand.find(isBlank),
    treasure = view.hand.find(isTreasure)
  if (blank)
    view.lanes.forEach((lane, laneIndex) =>
      lane.forEach((_, index) =>
        plans.push({ kind: "blank", cardId: blank.id, lane: laneIndex, index }),
      ),
    )
  if (treasure)
    for (const opponent of view.opponents)
      if (!opponent.riichi && opponent.hiddenCount)
        plans.push({ kind: "treasure", cardId: treasure.id, target: opponent.seat })
  if (!plans.length) {
    const current = valuePlan(view, undefined, worlds, pot)
    return { selected: current, current, options: [], available: false }
  }
  const options = plans
    .map((plan) => valuePlan(view, plan, worlds, pot))
    .sort((a, b) => b.utility - a.utility)
  const selected =
    (policy === "hold"
      ? options.find((o) => o.plan.kind !== "treasure")
      : policy === "exchange"
        ? options.find((o) => o.plan.kind === "treasure")
        : options[0]) ?? options[0]
  const current = valuePlan(view, undefined, worlds, pot)
  return { selected, current, options, available: true }
}

function choosePass(view: BotView): string[] {
  let best: string[] = [],
    bestValue = -Infinity
  for (let i = 0; i < view.hand.length; i++)
    for (let j = i + 1; j < view.hand.length; j++) {
      const kept = view.hand.filter((_, k) => k !== i && k !== j)
      const value = handUtility(kept, view.treasureAnte, view.treasureSets)
      if (value > bestValue) {
        bestValue = value
        best = [view.hand[i].id, view.hand[j].id]
      }
    }
  return best
}

function chooseReveal(view: BotView, count: number): string[] {
  const all = [...view.hand, ...view.publicCards]
  const selected = new Set(evaluateLegacy(all, view.treasureSets).selectedCardIds)
  return [...view.hand]
    .sort((a, b) => {
      const value = (card: Card) =>
        (selected.has(card.id) ? 100 : 0) +
        (isTreasure(card) ? view.treasureAnte * 4 : 0) -
        (isBlank(card) ? 20 : 0) -
        (card.kind === "flower" && lotusCount(all) === 1 ? 80 : 0)
      return value(b) - value(a)
    })
    .slice(0, count)
    .map((c) => c.id)
}

function chooseDiscard(view: BotView): { discardCardId: string; discardPile: DiscardPile } {
  let best = view.hand[0],
    bestValue = -Infinity
  for (const card of view.hand) {
    const kept = [...view.hand.filter((c) => c.id !== card.id), ...view.publicCards]
    const value = handUtility(kept, view.treasureAnte, view.treasureSets)
    if (value > bestValue) {
      best = card
      bestValue = value
    }
  }
  const helping = (seat: number) => {
    const opponent = view.opponents.find((o) => o.seat === seat)
    if (!opponent) return -1
    return (
      handUtility([...opponent.publicCards, best], view.treasureAnte, view.treasureSets) -
      handUtility(opponent.publicCards, view.treasureAnte, view.treasureSets)
    )
  }
  return {
    discardCardId: best.id,
    discardPile: helping(view.left) <= helping(view.right) ? "a" : "b",
  }
}

/** Exact hidden-card audit runs AFTER the policy decision and never feeds it. */
function auditOpportunity(
  engine: LegacyEngine,
  view: BotView,
  options: PlanValue[],
  chosen: string,
): TreasureOpportunity | undefined {
  const exchange = options.find((o) => o.plan.kind === "treasure")
  if (!exchange || exchange.plan.kind !== "treasure") return
  const target = engine.state.players[exchange.plan.target]
  const before = evaluateLegacy([...target.privateCards, ...target.publicCards], view.treasureSets)
  const gift = view.hand.find(
    (c) => c.id === (exchange.plan as Extract<FishPlan, { kind: "treasure" }>).cardId,
  )!
  let damaged = 0
  for (const card of target.privateCards) {
    const after = evaluateLegacy(
      [...target.privateCards.filter((c) => c.id !== card.id), gift, ...target.publicCards],
      view.treasureSets,
    )
    if (compareHandStrengths(after, before) < 0) damaged++
  }
  return {
    street: view.street,
    actor: view.seat,
    chosen,
    treasureCount: treasureCount(view.hand),
    options: [exchange, ...options.filter((o) => o.plan.kind !== "treasure").slice(0, 1)],
    damagedFraction: damaged / target.privateCards.length,
    eligibleHiddenCards: target.privateCards.length,
  }
}

export function stepLegacy(
  engine: LegacyEngine,
  samples: number,
  opportunities: TreasureOpportunity[],
): void {
  const state = engine.state
  if (state.phase === "between-hands") {
    engine.startNextHand()
    engine.assertCards()
    return
  }
  const id = state.actingPlayerId
  if (!id) throw new Error(`No actor in ${state.phase}`)
  const seat = engine.seat(id),
    player = state.players[seat],
    view = botView(engine, seat)
  if (state.phase === "charleston") {
    if (player.chips < 100 && player.loans === 0) engine.takeLoan(id)
    engine.passCharleston(id, choosePass(view))
    return
  }
  if (state.phase === "exposing") {
    engine.exposeCards(id, chooseReveal(view, STREET_REVEAL_COUNTS[state.street - 1] ?? 0))
    return
  }
  if (state.phase === "discarding") {
    engine.discard(id, chooseDiscard(view))
    return
  }
  if (state.phase !== "betting") throw new Error(`Unexpected ${state.phase}`)
  const legal = engine.legalActions(id)
  const call = legal.find((a) => a.type === "call" || a.type === "check")!
  const cost = call.callAmount ?? 0
  const plan = chooseFishing(
    view,
    samples,
    `${state.config.seed}:policy:${state.handNumber}:${state.version}:${seat}`,
    engine.options.policies?.[seat] ?? engine.options.exchangePolicy,
    state.pot + cost,
  )
  const callValue = (player.riichi ? plan.current : plan.selected).utility - cost
  let action: BettingAction = { type: call.type as "call" | "check" }
  if (!engine.options.checkdown && cost > 0 && callValue < 0) action = { type: "fold" }
  const bet = legal.find((a) => a.type === "bet")
  const raises = state.bettingHistory.filter(
    (r) => r.street === state.street && r.type === "bet",
  ).length
  const showdownEquity = plan.current.equity
  const random = new SeededRandom(
    `${state.config.seed}:bet:${state.handNumber}:${state.version}:${seat}`,
  )
  if (
    !engine.options.checkdown &&
    bet &&
    raises < 2 &&
    (showdownEquity > (raises ? 0.65 : 0.5) || (showdownEquity > 0.05 && random.next() < 0.035))
  ) {
    const desired = Math.floor((state.currentWager + Math.max(5, state.pot * 0.45)) / 5) * 5
    const maximum = Math.min(
      bet.maximum!,
      player.roundCommitted + Math.floor((player.chips * 0.4) / 5) * 5,
    )
    const amount = Math.max(bet.minimum!, Math.min(desired, maximum))
    if (amount <= bet.maximum! && amount <= maximum)
      action = {
        type: "bet",
        amount,
        riichi: Boolean(
          bet.canRiichi &&
          showdownEquity > 0.8 &&
          plan.selected.utility - plan.current.utility < view.ante,
        ),
      }
  }
  const plans: FishPlan[] = []
  if (action.type !== "fold" && !player.riichi && !(action.type === "bet" && action.riichi)) {
    if (action.type !== "bet") plans.push(plan.selected.plan)
    else if (
      bet?.canUseRiichiStick &&
      plan.selected.utility > plan.current.utility + view.ante * 0.3
    ) {
      action.useRiichiStick = true
      plans.push(plan.selected.plan)
    }
  }
  if (plans.length) {
    const opportunity = auditOpportunity(engine, view, plan.options, plan.selected.plan.kind)
    if (opportunity) opportunities.push(opportunity)
  }
  engine.actWithFish(id, action, plans)
  engine.assertCards()
}
