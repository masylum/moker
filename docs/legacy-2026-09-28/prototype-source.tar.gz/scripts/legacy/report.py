"""Summarize the checked-in Legacy experiment using Python's standard library."""
from pathlib import Path
import hashlib
import json
import random
import statistics
import subprocess

ROOT = Path(__file__).resolve().parents[2]
OUT = ROOT / 'docs' / 'legacy-2026-09-28'

def load(name):
    return json.loads((OUT / f'{name}.json').read_text())

def summarize(data):
    games = data['results']
    rounds = sum(g['rounds'] for g in games)
    opportunities = sum(s['opportunities'] for g in games for s in g['byStreet'])
    exchanges = [x for g in games for x in g['exchanges']]
    return dict(games=len(games), finished=sum(g['finished'] for g in games), rounds=rounds,
        showdown=sum(g['showdown'] for g in games), bonuses=sum(g['bonuses'] for g in games),
        opportunities=opportunities, exchanges=len(exchanges),
        rate=len(exchanges)/max(1, opportunities),
        target_weakened=sum(x['targetWeakened'] for x in exchanges),
        actor_improved=sum(x['actorImproved'] for x in exchanges),
        collection_min=min(min(g['finalCollectionSizes']) for g in games),
        collection_max=max(max(g['finalCollectionSizes']) for g in games))

def bootstrap(values, seed):
    rng = random.Random(seed)
    means = sorted(statistics.mean(rng.choices(values, k=len(values))) for _ in range(5000))
    return [statistics.mean(values), means[125], means[4874]]

def pct(n, d):
    return f'{100*n/max(1,d):.1f}%'

names = ['payout0', 'payout2', 'payout4', 'payout4-sets']
labels = ['No payout, no sets', '2× ante, no sets', '4× ante, no sets', '4× ante + sets']
data = {name: load(name) for name in names}
summary = {name: summarize(d) for name, d in data.items()}
base = summary['payout4']
basegames = data['payout4']['results']

lines = [
    '# Legacy: simulation and ladder report', '',
    'Candidate: player-owned lanes, personal persistent decks, rank-fixed wilds, Quints above Kongs, and four distinct Treasures. The requested Treasure payout is 4× ante per card at contested showdown. This is a headless branch prototype, not a deployed or browser-playable expansion.', '',
    '## Findings', '',
    '- The 4× payout makes Treasures chiefly worth keeping. Exchanges still have tactical uses, especially in larger pots and later streets. Reducing the payout increases exchange use substantially in these bots.',
    '- Start with payout-only Treasures. Adding scoring sets changes relatively little in these runs, adds another hoarding reward, and places Three Treasures below substantially more common combinations.',
    '- Quints correctly outrank Kongs. Their initial-deal frequency is extremely low; their long-term attainability should be judged separately from ordinary random deals.',
    '- Persistent collection sizes can reach seven cards. Mandatory eight-card setup then fails; the seven-card seed exception is tested below as a separate proposed rule.',
    '- These results establish behavior of the specified heuristic policies, not optimal play or a statistically decisive policy ranking.', '',
    '## Matched-seed payout comparison', '',
    'Each arm uses 100 four-player sessions, two dealer orbits (up to eight rounds), 24 sampled worlds per decision, and seeds `legacy-v1:0` through `legacy-v1:99`. Initial deck allocations match across arms. Game trajectories diverge after different actions. Folds, Riichi, loans, all-ins, and Lotus rules use the existing betting engine.', '',
    '| Treasure rule | Completed sessions | Rounds | Showdowns | Exchanges / eligible fishing decisions | Exchange rate | Reserve chips / round |',
    '| --- | ---: | ---: | ---: | ---: | ---: | ---: |'
]
for name, label in zip(names, labels):
    s = summary[name]
    lines.append(f"| {label} | {s['finished']}/{s['games']} | {s['rounds']} | {s['showdown']} ({pct(s['showdown'],s['rounds'])}) | {s['exchanges']}/{s['opportunities']} | {100*s['rate']:.1f}% | {s['bonuses']/s['rounds']:.2f} |")
lines += ['',
    'An eligible fishing decision means the acting bot has a concealed Treasure, has an allowed target, and actually receives a fishing action. It excludes folds, locked hands, and bets without fishing. Repeated opportunities within a game are correlated.', '',
    f"In the 4× candidate, {base['target_weakened']} of {base['exchanges']} exchanges ({pct(base['target_weakened'], base['exchanges'])}) reduced the target's evaluated hand strength, including tie-break changes. Only {base['actor_improved']} ({pct(base['actor_improved'],base['exchanges'])}) immediately improved the giver's own evaluated hand strength. Those measures exclude Lotus disqualification, the lost/gained reserve payout, and future deck effects; they are not net-profit measures.", '',
    '## Why 1/n is not the whole disruption probability', '',
    'There can be several concealed cards whose removal weakens the target. A particular-card probability of 1/7 becomes 3/7 if three different cards are essential. Conversely, redundant cards and public anchors can make the useful-hit probability zero. The existing reveal schedule leaves 7, 4, 3, then 2 concealed cards.', '',
    '| Street | Eligible decisions | Treasure exchanges | Exchange rate | Mean true damage chance for the bot\'s preferred exchange target |',
    '| --- | ---: | ---: | ---: | ---: |'
]
for street in range(4):
    rows = [g['byStreet'][street] for g in basegames]
    n = sum(r['opportunities'] for r in rows)
    chosen = sum(r['chosen'] for r in rows)
    damage = sum(r['opportunities']*r['averageDamageProbability'] for r in rows)/max(1,n)
    lines.append(f'| {street+1} | {n} | {chosen} | {pct(chosen,n)} | {damage*100:.1f}% |')
lines += ['',
    'The damage column is a diagnostic computed after the decision by trying each possible concealed target card. It never supplies the bot with hidden information. It includes opportunities where the bot chose another action. Revealing made-hand anchors helps explain why later streets need not have higher damage probability despite fewer hidden cards.', '',
    'At a 5-chip ante, keeping one Treasure is worth 20 reserve chips if you reach showdown. Ignoring replacement Treasures and future effects, giving it away must increase expected pot winnings by more than that lost payout. In a 100-chip pot this requires roughly a 20-percentage-point equity improvement; a stronger alternative normal fish raises that threshold further. It is therefore naturally a late/large-pot option under the 4× rule.', '',
]
check = summarize(load('checkdown'))
lines += [
    f"A separate checkdown control (40 sessions, {check['rounds']} rounds, no bets or folds) made **{check['exchanges']} exchanges in {check['opportunities']} eligible decisions** at 4×. Average reserve injection was {check['bonuses']/check['rounds']:.2f} chips per round. Keeping the pot at its initial 20 chips makes the 20-chip Treasure payout particularly hard to sacrifice. This control is not representative normal betting play.", '',
    '## Sampling sensitivity and policy comparison', '',
]
high = summarize(load('payout4-samples96'))
low = summarize({'results': basegames[:40]})
lines += [f"For the same first 40 starting seeds, increasing decision samples from 24 to 96 changed exchange use from {low['exchanges']}/{low['opportunities']} ({100*low['rate']:.1f}%) to {high['exchanges']}/{high['opportunities']} ({100*high['rate']:.1f}%). This is a sensitivity check on Monte Carlo noise, not a convergence proof.", '']
mixed = load('mixed-policies')['results']
net = {policy: [] for policy in ['strategic', 'hold', 'exchange']}
paired = {'strategic-minus-hold': [], 'exchange-minus-hold': []}
for game in mixed:
    if not game['finished']:
        continue
    by_policy = {policy: [] for policy in net}
    for seat, policy in enumerate(game['policies']):
        score = game['scores'][f'p{seat+1}'] - 200
        by_policy[policy].append(score)
        net[policy].append(score)
    for policy in ['strategic', 'exchange']:
        paired[f'{policy}-minus-hold'].append(statistics.mean(by_policy[policy])-statistics.mean(by_policy['hold']))
intervals = {name: bootstrap(values, name) for name, values in paired.items()}
lines += ['In 120 mixed-policy sessions, each table had two strategic bots, one bot that never exchanges a Treasure, and one that exchanges whenever an eligible fishing opportunity exists. Policies rotate across seats. All share the same other heuristics. Scores include loan penalties; these are net score changes from the 200-point start.', '',
    '| Policy | Player-seats | Mean net score |', '| --- | ---: | ---: |']
for policy, scores in net.items():
    lines.append(f'| {policy} | {len(scores)} | {statistics.mean(scores):+.2f} |')
lines += ['', '| Within-table comparison | Mean score difference | Game-bootstrap 95% interval |', '| --- | ---: | ---: |']
for name, (mean, lo, hi) in intervals.items():
    lines.append(f'| {name} | {mean:+.2f} | [{lo:+.2f}, {hi:+.2f}] |')
lines += ['', 'Bootstrap intervals resample whole games (5,000 repetitions), preserving correlations among seats. A policy preference or raw average is not evidence that one strategy is optimal. In particular, the payout-comparison table measures willingness to exchange, not the causal win value of exchanging.', '',
    '## Ladder validation', '',
    '200,000 uniformly shuffled seven-card deals from the full 132-card deck. “Contains” checks every category independently; categories overlap. “Best” selects the strongest category. These are before Charleston or fishing, not achieved-hand rates. Single-Lotus disqualification is counted separately in the raw output.', '',
    '| Hand | Contains / 200,000 | Contains frequency | Best | Without wilds or Jokers: contains |',
    '| --- | ---: | ---: | ---: | ---: |']
ladder = load('ladder')['ladder']
for kind, row in ladder['rows'].items():
    lines.append(f"| {kind} | {row['contains']} | {100*row['contains']/ladder['samples']:.4f}% | {row['best']} | {row['naturalContains']} |")
q = ladder['exactQuintProbability']; four = ladder['exactFourTreasuresProbability']; three = ladder['exactAtLeastThreeTreasuresProbability']
lines += ['',
    f"The two rarest sample counts are too small for reliable frequency estimates. Exact initial-deal probabilities are **Quint: {100*q:.6f}% (about 1 in {1/q:,.0f})** and **Four Treasures: {100*four:.6f}% (about 1 in {1/four:,.0f})**. There are 34 possible five-card Quint sets; each requires all five physical cards, and two such sets cannot coexist within seven cards. Thus P(Quint) = 34 × C(127,2) / C(132,7). P(Four Treasures) = C(128,3) / C(132,7).", '',
    f"At least Three Treasures has exact probability {100*three:.4f}% (about 1 in {1/three:,.0f}). Its proposed position below Three Dragons and Eyes and Four Winds is not supported by simple rarity. Giving it a payout as well does not resolve that ordering issue; payout-only Treasures avoid it.", '',
    'The existing ladder also has rarity inversions: Chow and Eyes is rarer than Pung, and Pung and Eyes is rarer than Three Dragons in these opening deals. This does not by itself prove the ladder is wrong: achievable progress and exchange opportunities matter. Preserve the existing order provisionally and do not describe the whole ladder as statistically calibrated.', '',
    'The Legacy evaluator was checked against the existing Riichi evaluator on 1,000 ordinary random hands and against exhaustive suit assignments on 400 random hands. Targeted cases cover wild pairs, fixed ranks, wild Dragons, Wind and suited Quints, Joker pair restrictions, and preventing reuse of a wild card across a compound hand.', '',
    'Achieved hands in the 4× payout-only arm:', '',
    '| Best hand at contested showdown | Contender hands | Fractional pot wins |', '| --- | ---: | ---: |']
ranks = {}
for game in basegames:
    for kind, counts in game['ranks'].items():
        row = ranks.setdefault(kind, {'count': 0, 'wins': 0})
        for key in row: row[key] += counts[key]
for kind in ladder['rows']:
    counts = ranks.get(kind, {'count': 0, 'wins': 0})
    if counts['count'] or kind == 'quint': lines.append(f"| {kind} | {counts['count']} | {counts['wins']:g} |")
lines += ['', 'Contender hands include lone-Lotus losers. Win counts divide ties fractionally. These conditional outcomes are influenced by folding and bot choices; they are not an unbiased measure of category value.', '',
    '## Persistent decks and the seven-card problem', '',
    f"Four-player collection sizes in the primary 4× arm ended between {base['collection_min']} and {base['collection_max']} cards, despite starting at 33 each. This follows the corrected destination-lane ownership rule: your discard feeds the neighbor's future collection, not your own. Exact card conservation was checked after moves.", '',
    '| Stress configuration | Completed sessions | Recorded rounds | Setup failures |', '| --- | ---: | ---: | ---: |']
for name, label in [('stress-2','2 players, four orbits'), ('stress-3','3 players, four orbits'), ('stress-5','5 players, four orbits'), ('stress-6','6 players, four orbits'), ('tournament','4 players, three two-orbit games')]:
    s = summarize(load(name)); summary[name] = s
    lines.append(f"| {label} | {s['finished']}/{s['games']} | {s['rounds']} | {s['games']-s['finished']} |")
lines += ['', 'Failed sessions stop and remain labelled unfinished; they are not counted as completed matches or silently repaired. The observed failures occurred at the next eight-card deal when a collection had seven cards.', '',
    'Separate proposed rule: **when your collection has exactly seven cards, deal seven and skip your seed discard**. You still take part in Charleston and retain a seven-card hand. The following repeats use the same starting seeds with only that exception enabled:', '',
    '| Configuration with seed exception | Completed sessions | Recorded rounds | Remaining failures |', '| --- | ---: | ---: | ---: |']
for name, label in [('stress-5-skip-seed','5 players, four orbits'), ('stress-6-skip-seed','6 players, four orbits'), ('tournament-skip-seed','4 players, three two-orbit games')]:
    s = summarize(load(name)); summary[name] = s
    failures = [g['failure'] for g in load(name)['results'] if not g['finished']]
    lines.append(f"| {label} | {s['finished']}/{s['games']} | {s['rounds']} | {'; '.join(failures) or 'None'} |")
lines += ['', 'Skipping the seed alone can expose a second gap: no legal fishing source. A further experimental exception forfeits the unavailable fish while allowing betting to continue. It does not let players choose to skip when any legal draw or exchange exists.', '',
    '| Both recovery exceptions | Completed sessions | Recorded rounds | Remaining failures |', '| --- | ---: | ---: | ---: |']
for name, label in [('stress-5-recovery', '5 players, four orbits'), ('stress-6-recovery', '6 players, four orbits')]:
    s = summarize(load(name)); summary[name] = s
    failures = [g['failure'] for g in load(name)['results'] if not g['finished']]
    lines.append(f"| {label} | {s['finished']}/{s['games']} | {s['rounds']} | {'; '.join(failures) or 'None'} |")
lines += ['', 'These exceptions are experimental and have not replaced the requested baseline. Fixed lanes belonging to eliminated players can also park cards outside active circulation.', '',
    '## Scope and limitations', '',
    '- The policy samples uniform unseen opponent cards, not fully inferred ranges conditioned on prior reveals and bets. It remembers public acquisitions and its own known returning deck cards, but future deck-building strategy is shallow.',
    '- Fishing utility uses sampled current showdown equity, a conditional Treasure bonus, and a small development term. Earlier bonuses receive an explicit survival discount. This approximation can affect choices.',
    '- Stick fishing after bets is supported by the policy; extra stick fishing after Check/Call is not optimized. The underlying betting rules remain Riichi.',
    '- No public UI, production card schema, online save format, or browser name gate has been implemented. The headless adapter must not be loaded as a production game save.',
    '- Single-Lotus players at contested showdown receive Treasure payouts, but folded players and uncontested winners do not. Riichi-locked players cannot be Treasure targets. These are explicit prototype interpretations.',
    '- These experiments support a rules discussion and human playtest. They do not certify balance, solve the game, or establish a reliable optimal Treasure-exchange policy.', '',
    '## Verification', '',
    '227 unit tests and 13 Worker integration tests passed, including 20 Legacy tests. Repository lint, dead-code checks, and TypeScript checks passed. All changed files pass formatting and whitespace checks. The aggregate `npm run check` is blocked by existing formatting issues in unchanged `docs/twin-lotus-2026-09-27` archives; those files were left untouched.', '',
    '## Reproduce', '',
    'Run from the repository root. The exact options for each arm are saved in its JSON file. See [prototype rules](../legacy-prototype.md) for commands and card encoding. Additional examples:', '',
    '```bash',
    'node --import tsx scripts/legacy-simulate.ts --games 12 --players 6 --samples 24 --orbits 4 --short-deck skip-seed --output /tmp/legacy-six.json',
    'node --import tsx scripts/legacy-simulate.ts --games 40 --samples 96 --orbits 2 --output /tmp/legacy-high-samples.json',
    'python3 scripts/legacy/report.py',
    '```', '',
    'Source hashes are recorded in `source-hashes.json`. `summary.json` contains the report aggregates and policy confidence intervals. Raw per-session results are retained alongside this report.', ''
]
(OUT / 'README.md').write_text('\n'.join(lines))
(OUT / 'summary.json').write_text(json.dumps({'arms': summary, 'mixed_net_scores': {k: statistics.mean(v) for k,v in net.items()}, 'mixed_paired_intervals': intervals, 'sample_sensitivity': {'24':low,'96':high}}, indent=2)+'\n')
paths = sorted([* (ROOT/'src/game').glob('*.ts'), * (ROOT/'scripts/legacy').glob('*.ts'), ROOT/'scripts/legacy-simulate.ts', ROOT/'tests/legacy.test.ts', Path(__file__).resolve()])
manifest = {'baseCommit': subprocess.check_output(['git','rev-parse','HEAD'], cwd=ROOT, text=True).strip(), 'sha256': {str(p.relative_to(ROOT)):hashlib.sha256(p.read_bytes()).hexdigest() for p in paths}}
(OUT/'source-hashes.json').write_text(json.dumps(manifest, indent=2)+'\n')
print(json.dumps({'arms':summary, 'intervals':intervals, 'sensitivity':{'24':low, '96':high}}, indent=2))
