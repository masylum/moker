import { mkdirSync, writeFileSync } from "node:fs"
import { dirname } from "node:path"
import { parseArgs } from "node:util"
import { SeededRandom } from "../src/game/random"
import { compareHandStrengths } from "../src/game/scoring"
import { legacyDeck, lotusCount, treasureCount } from "./legacy/cards"
import { evaluateLegacy, LEGACY_LADDER, type LegacyKind } from "./legacy/scoring"
import { DeckExhausted, LegacyEngine } from "./legacy/engine"
import { stepLegacy, type TreasureOpportunity } from "./legacy/bots"

const { values } = parseArgs({
  options: {
    games: { type: "string", default: "10" },
    players: { type: "string", default: "4" },
    orbits: { type: "string", default: "2" },
    samples: { type: "string", default: "12" },
    "treasure-ante": { type: "string", default: "4" },
    sets: { type: "boolean", default: false },
    "skip-unavailable-fish": { type: "boolean", default: false },
    "short-deck": { type: "string", default: "stop" },
    checkdown: { type: "boolean", default: false },
    policy: { type: "string", default: "strategic" },
    seed: { type: "string", default: "legacy-v1" },
    offset: { type: "string", default: "0" },
    ladder: { type: "string", default: "0" },
    output: { type: "string" },
    "tournament-games": { type: "string", default: "1" },
  },
})
const games = Number(values.games),
  players = Number(values.players),
  orbits = Number(values.orbits),
  samples = Number(values.samples)
const treasureAnte = Number(values["treasure-ante"]),
  ladder = Number(values.ladder),
  offset = Number(values.offset)
const tournamentGames = Number(values["tournament-games"]) as 1 | 2 | 3 | 4
if (
  ![games, players, orbits, samples, ladder, offset, tournamentGames].every(Number.isInteger) ||
  games < 0 ||
  players < 2 ||
  players > 6 ||
  orbits < 1 ||
  orbits > 4 ||
  samples < 1 ||
  ladder < 0 ||
  offset < 0 ||
  !["stop", "skip-seed"].includes(values["short-deck"]!) ||
  ![1, 2, 3, 4].includes(tournamentGames) ||
  !["strategic", "hold", "exchange", "mixed"].includes(values.policy!) ||
  !Number.isFinite(treasureAnte) ||
  treasureAnte < 0
)
  throw new Error("Invalid simulation options")
const started = performance.now()
const output: Record<string, unknown> = {
  options: values,
  prototype: "headless Legacy atop rules-v6 betting; approximate information-limited bots",
  results: [],
}
const deck = legacyDeck(),
  byId = new Map(deck.map((c) => [c.id, c]))

if (ladder) {
  const random = new SeededRandom(`${values.seed}:ladder`)
  const rows = Object.fromEntries(
    LEGACY_LADDER.map((kind) => [
      kind,
      { contains: 0, best: 0, winningEligibleBest: 0, naturalContains: 0 },
    ]),
  )
  let singleLotus = 0
  for (let i = 0; i < ladder; i++) {
    const hand = random.shuffle(deck).slice(0, 7),
      contains = new Set<LegacyKind>()
    const score = evaluateLegacy(hand, values.sets, contains)
    const natural = new Set<LegacyKind>()
    evaluateLegacy(
      hand.filter((c) => !c.id.startsWith("wild-") && c.kind !== "joker"),
      values.sets,
      natural,
    )
    rows[score.kind].best++
    if (lotusCount(hand) === 1) singleLotus++
    else rows[score.kind].winningEligibleBest++
    for (const kind of contains) rows[kind].contains++
    for (const kind of natural) rows[kind].naturalContains++
  }
  const choose = (n: number, k: number) => {
    let result = 1
    for (let i = 1; i <= k; i++) result = (result * (n - i + 1)) / i
    return result
  }
  output.ladder = {
    samples: ladder,
    rows,
    singleLotus,
    exactQuintProbability: (34 * choose(127, 2)) / choose(132, 7),
    exactFourTreasuresProbability: choose(128, 3) / choose(132, 7),
    exactAtLeastThreeTreasuresProbability: (4 * choose(128, 4) + choose(128, 3)) / choose(132, 7),
  }
}

const results: unknown[] = []
for (let i = offset; i < offset + games; i++) {
  const policies =
    values.policy === "mixed"
      ? Array.from(
          { length: players },
          (_, seat) => (["strategic", "strategic", "hold", "exchange"] as const)[(seat + i) % 4],
        )
      : undefined
  const game = LegacyEngine.createLegacy({
    seed: `${values.seed}:${i}`,
    players,
    orbits,
    games: tournamentGames,
    treasureAnte,
    treasureSets: values.sets!,
    policies,
    shortDeck: values["short-deck"] as "stop" | "skip-seed",
    skipUnavailableFish: values["skip-unavailable-fish"],
    checkdown: values.checkdown,
    exchangePolicy: values.policy as "strategic" | "hold" | "exchange",
  })
  const opportunities: TreasureOpportunity[] = []
  let steps = 0,
    failure: string | null = null
  try {
    while (game.state.phase !== "finished") {
      if (++steps > 10_000) throw new Error("Step limit exceeded")
      stepLegacy(game, samples, opportunities)
      // Bound event memory; history needed by the engine stays in its state.
    }
  } catch (error) {
    if (!(error instanceof DeckExhausted)) throw error
    failure = error.message
  }
  const resultsByRank: Record<string, { count: number; wins: number }> = {}
  const rounds = game.state.handResults
  for (const round of rounds.filter((r) => r.reason === "showdown"))
    for (const p of round.players.filter((player) => !player.folded && !player.eliminated)) {
      const kind = evaluateLegacy(p.cards, values.sets).kind
      const row = resultsByRank[kind] ?? { count: 0, wins: 0 }
      row.count++
      if (round.winnerIds.includes(p.playerId)) row.wins += 1 / round.winnerIds.length
      resultsByRank[kind] = row
    }
  const exchanges = game.exchanges.map((exchange) => {
    const evaluate = (ids: string[]) =>
      evaluateLegacy(
        ids.map((id) => byId.get(id)!),
        values.sets,
      )
    const before = evaluate(exchange.targetBefore),
      after = evaluate(exchange.targetAfter)
    const ownBefore = evaluate(exchange.actorBefore),
      ownAfter = evaluate(exchange.actorAfter)
    return {
      street: exchange.street,
      hidden: exchange.targetHiddenCount,
      targetWeakened: compareHandStrengths(after, before) < 0,
      targetRankDropped: after.total < before.total,
      actorImproved: compareHandStrengths(ownAfter, ownBefore) > 0,
      takenTreasure: exchange.drawn.startsWith("treasure-"),
      beforeKind: before.kind,
      afterKind: after.kind,
      taken: exchange.drawn,
    }
  })
  const byStreet = Array.from({ length: 4 }, (_, street) => {
    const opts = opportunities.filter((o) => o.street === street + 1)
    return {
      street: street + 1,
      opportunities: opts.length,
      chosen: opts.filter((o) => o.chosen === "treasure").length,
      averageDamageProbability:
        opts.reduce((sum, o) => sum + o.damagedFraction, 0) / Math.max(1, opts.length),
      hiddenCounts: opts.map((o) => o.eligibleHiddenCards),
    }
  })
  const result = {
    index: i,
    policies,
    seed: game.state.config.seed,
    finished: game.state.phase === "finished",
    failure,
    steps,
    rounds: rounds.length,
    showdown: rounds.filter((r) => r.reason === "showdown").length,
    uncontested: rounds.filter((r) => r.reason === "uncontested").length,
    allInRounds: rounds.filter((r) => r.allInPlayerIds.length).length,
    street4Rounds: rounds.filter((r) => r.bettingHistory.some((b) => b.street === 4)).length,
    bonuses: game.bonuses.reduce((sum, b) => sum + b.amount, 0),
    drawCounts: game.drawCounts,
    scores: game.state.finalScores,
    ranks: resultsByRank,
    deckSizes: game.deckSizes,
    roundTreasureHolders: rounds.map((r) =>
      r.players.filter((p) => !p.folded && !p.eliminated).map((p) => treasureCount(p.cards)),
    ),
    byStreet,
    exchanges,
    examples: opportunities.filter((o) => o.chosen === "treasure").slice(0, 3),
    calls: rounds.flatMap((r) => r.bettingHistory).filter((a) => a.type === "call").length,
    folds: rounds.flatMap((r) => r.bettingHistory).filter((a) => a.type === "fold").length,
    bets: rounds.flatMap((r) => r.bettingHistory).filter((a) => a.type === "bet").length,
    riichi: rounds.filter((r) => r.riichiSettlement.declaredPlayerId).length,
    loans: game.state.players.reduce((sum, p) => sum + p.loans, 0),
    finalChipTotal: game.state.players.reduce((sum, p) => sum + p.chips, 0),
    finalCollectionSizes: game.state.players.map(
      (p, seat) =>
        game.decks[seat].length +
        game.lanes[seat].length +
        (game.state.foldedPrivateCards[p.id] ?? p.privateCards).length +
        p.publicCards.length,
    ),
  }
  results.push(result)
  if ((i - offset + 1) % 5 === 0 || i === offset + games - 1)
    console.log(
      `${values.policy}/bonus${treasureAnte}/sets${values.sets}: ${i - offset + 1}/${games}; ${((performance.now() - started) / 1000).toFixed(1)}s`,
    )
}
output.results = results
output.seconds = (performance.now() - started) / 1000
if (values.output) {
  mkdirSync(dirname(values.output), { recursive: true })
  writeFileSync(values.output, JSON.stringify(output, null, 2) + "\n")
} else console.log(JSON.stringify(output, null, 2))
